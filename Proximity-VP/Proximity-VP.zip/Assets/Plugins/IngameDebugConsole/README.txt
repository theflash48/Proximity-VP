= In-game Debug Console (v1.8.2) =

Documentation: https://github.com/yasirkula/UnityIngameDebugConsole
FAQ: https://github.com/yasirkula/UnityIngameDebugConsole#faq
E-mail: yasirkula@gmail.com

You can simply place the IngameDebugConsole prefab to your scene. Hovering the cursor over its properties in the Inspector will reveal explanatory tooltips.